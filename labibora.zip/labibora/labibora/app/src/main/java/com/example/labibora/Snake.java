package com.example.labibora;

import java.util.ArrayList;

public class Snake {
    private ArrayList<int[]> snake;
    private int direction;
    private final int blockSize;
    private boolean dead;

    public Snake(int initialX, int initialY, int blockSize) {
        this.snake = new ArrayList<>();
        this.snake.add(new int[]{initialX, initialY});
        this.blockSize = blockSize;
        this.direction = 1; // 0 = arriba, 1 = derecha, 2 = abajo, 3 = izquierda
        this.dead = false;
    }

    public ArrayList<int[]> getSnake() {
        return snake;
    }

    public void move() {
        if (!dead) {
            int[] head = snake.get(0);
            int newX = head[0];
            int newY = head[1];

            // Mover la cabeza de la serpiente en la dirección actual
            switch (direction) {
                case 0: // Arriba
                    newY--;
                    break;
                case 1: // Derecha
                    newX++;
                    break;
                case 2: // Abajo
                    newY++;
                    break;
                case 3: // Izquierda
                    newX--;
                    break;
            }

            // Insertar la nueva cabeza al principio de la serpiente
            snake.add(0, new int[]{newX, newY});

            // Simular movimiento al eliminar la última parte
            if (snake.size() > 1) {
                snake.remove(snake.size() - 1);
            }
        }
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public void checkCollision(int width, int height) {
        int[] head = snake.get(0);
        if (head[0] < 0 || head[0] >= width || head[1] < 0 || head[1] >= height || snakeContains(head)) {
            dead = true;
        }
    }

    private boolean snakeContains(int[] head) {
        for (int i = 1; i < snake.size(); i++) {
            if (snake.get(i)[0] == head[0] && snake.get(i)[1] == head[1]) {
                return true;
            }
        }
        return false;
    }

    public boolean isDead() {
        return dead;
    }

    public void reset(int initialX, int initialY) {
        snake.clear();
        snake.add(new int[]{initialX, initialY});
        direction = 1; // Resetear a la dirección inicial (derecha)
        dead = false;
    }
}