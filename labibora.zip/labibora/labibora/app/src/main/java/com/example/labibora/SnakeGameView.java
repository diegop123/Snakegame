package com.example.labibora;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class SnakeGameView extends View {

    private int width, height;
    private Paint paint;
    private Snake snake;
    private int[] food;
    private Random random;
    private Handler handler;
    private AlertDialog alertDialog; // Declaración de la variable alertDialog
    private final int blockSize = 50;

    public SnakeGameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        snake = new Snake(5, 5, blockSize);
        random = new Random();
        handler = new Handler();

        handler.postDelayed(() -> {
            if (width > 0 && height > 0) {
                placeFood();
            }
        }, 100);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        width = w / blockSize;
        height = h / blockSize;

        if (width > 0 && height > 0) {
            placeFood();
        }
    }

    private void placeFood() {
        if (width > 0 && height > 0) {
            food = new int[]{random.nextInt(width), random.nextInt(height)};
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(Color.GREEN);
        paint.setColor(Color.BLUE);
        for (int[] part : snake.getSnake()) {
            canvas.drawRect(part[0] * blockSize, part[1] * blockSize, (part[0] + 1) * blockSize, (part[1] + 1) * blockSize, paint);
        }

        // Dibuja la comida
        if (food != null) {
            paint.setColor(Color.RED);
            canvas.drawRect(food[0] * blockSize, food[1] * blockSize, (food[0] + 1) * blockSize, (food[1] + 1) * blockSize, paint);
        }

        if (!snake.isDead()) {
            snake.move();
            snake.checkCollision(width, height);

            if (snake.getSnake().get(0)[0] == food[0] && snake.getSnake().get(0)[1] == food[1]) {
                placeFood();  // Coloca nueva comida
            }

            handler.postDelayed(this::invalidate, 300);
        } else {
            showGameOver();
        }
    }

    private void showGameOver() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.dialog_game_over, null);
        builder.setView(dialogView);

        // Configurar el botón de reiniciar
        Button restartButton = dialogView.findViewById(R.id.restart_button);
        restartButton.setOnClickListener(v -> {
            restartGame();
            alertDialog.dismiss();
        });

        // Crear y mostrar el diálogo
        alertDialog = builder.create(); // Asigna la instancia a alertDialog
        alertDialog.setCancelable(false); // Para que no se cierre tocando fuera
        alertDialog.show();
    }

    private void restartGame() {
        snake.reset(5, 5); // Reinicia la serpiente a la posición inicial
        placeFood(); // Recoloca la comida
        invalidate(); // Redibuja
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        int newDirection = -1;

        // Control de dirección
        if (x < getWidth() / 2) {
            newDirection = 3; // Izquierda
        } else {
            newDirection = 1; // Derecha
        }

        if (y < getHeight() / 2) {
            newDirection = 0; // Arriba
        } else {
            newDirection = 2; // Abajo
        }

        // Cambia la dirección si no está en la misma dirección opuesta
        if (snake.getSnake().size() > 1 && Math.abs(snake.getSnake().get(0)[0] - newDirection) != 1) {
            snake.setDirection(newDirection);
        }

        return super.onTouchEvent(event);
    }
}